from fastapi import FastAPI, __version__
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import PlainTextResponse

from app.common.constants.api import ALLOWED_METHODS, SELECTED_ALL
from app.routes import whatsapp

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=SELECTED_ALL,
    allow_credentials=True,
    allow_methods=ALLOWED_METHODS,
    allow_headers=SELECTED_ALL
)


@app.get('/', tags=["Health Check"], response_class=PlainTextResponse)
async def health_check() -> str:
    return f"Hello from FastAPI: {__version__}"

app.include_router(whatsapp.router)
