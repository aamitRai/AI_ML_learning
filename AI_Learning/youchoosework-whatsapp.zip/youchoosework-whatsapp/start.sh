uvicorn main:app --host "0.0.0.0" --log-level "error"
