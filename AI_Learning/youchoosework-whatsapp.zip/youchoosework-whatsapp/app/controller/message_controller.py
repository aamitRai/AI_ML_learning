from app.common.constants.logs import AGENT_CONNECTED_LOG, RECEIVE_REQUEST_ID_LOG
from app.common.enums.status_enum import StatusEnum
from app.common.helpers.logger_helper import logger
from app.common.types.requests.whatsapp_incoming_request import WhatsappIncomingRequest
from app.processor.message_processor import MessageProcessor
from app.services.live_agent_service import LiveAgentService
from app.services.ticket_service import TicketService


class MessageController:

    def __init__(self, message_processor: MessageProcessor, ticket_service: TicketService, live_agent_service: LiveAgentService) -> None:
        self.__message_processor = message_processor
        self.__ticket_service = ticket_service
        self.__live_agent_service = live_agent_service

    async def message_controller(self, request: WhatsappIncomingRequest) -> dict | None:
        try:
            message = request.entry[0].changes[0].value.messages[0]
            if message:
                sender_id = message.sender
                logger.info(f"{RECEIVE_REQUEST_ID_LOG} {message.id}")
                ticket_status = await self.__ticket_service.get_ticket_status(sender_id=message.sender)
                incoming_value = request.entry[0].changes[0].value
                await self.__live_agent_service.send_user_message_to_live_agent(incoming_value=incoming_value, sender_id=sender_id)
                if ticket_status != StatusEnum.INPROGRESS.value and ticket_status != StatusEnum.NEW.value:
                    await self.__message_processor.process_message(incoming_request=incoming_value)
                logger.info(AGENT_CONNECTED_LOG)
            return {"status": "ohk"}
        except Exception as ex:
            logger.exception(ex)
            return
