from enum import Enum


class MongoTableEnum(str, Enum):
    
    CENTERS = 'centers'
    WORKERS = 'workers'
    QUALIFICATIONS = 'qualifications'
    WAGES = 'wages'
