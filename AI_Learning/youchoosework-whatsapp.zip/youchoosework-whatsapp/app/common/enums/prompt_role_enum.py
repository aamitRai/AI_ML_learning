from enum import Enum


class PromptRoleEnum(str, Enum):

    SYSTEM = "system"
    DEVELOPER = "developer"
    ASSISTANT = "assistant"
    USER = "user"
