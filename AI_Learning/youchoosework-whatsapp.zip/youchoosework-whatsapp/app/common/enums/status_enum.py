
from enum import Enum


class StatusEnum(Enum):

    NEW = "NEW"
    INPROGRESS = "INPROGRESS"
    CLOSED = "CLOSED"
    ASSIGNED = "ASSIGNED"
    HIDDEN = "HIDDEN"
