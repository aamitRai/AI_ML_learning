from enum import Enum


class MessageTypesEnum(Enum):

    TEXT = "text"
    BUTTON = "button"
    INTERACTIVE = "interactive"
    LIST_REPLY = "list_reply"
    BUTTON_REPLY = "button_reply"
    BUTTONS = "buttons"
    LIST = "list"
