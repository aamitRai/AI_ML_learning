from pydantic import BaseModel


class Info(BaseModel):
    key: str
    value: str


class BotMessageData(BaseModel):
    ignoreTicketInfo: bool = True
    organisationId: str
    tenantId: str
    botId: str
    customerId: str
    userInfo: list[Info]
    messages: list[dict]
    channelType: int
