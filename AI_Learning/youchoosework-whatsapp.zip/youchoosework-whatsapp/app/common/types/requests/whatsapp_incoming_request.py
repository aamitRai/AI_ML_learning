from pydantic import BaseModel, Field
from typing import Any, Optional


class Text(BaseModel):
    body: str


class Button(BaseModel):
    payload: str
    text: str


class ButtonReply(BaseModel):
    id: str
    title: str


class ListReply(BaseModel):
    id: str
    title: str
    description: Optional[str] = ""


class Interactive(BaseModel):
    type: str
    button_reply: Optional[ButtonReply] = {}
    list_reply: Optional[ListReply] = {}


class Message(BaseModel):
    id: str
    type: str
    sender: str = Field(alias="from")
    text: Optional[Text] = {}
    button: Optional[Button] = {}
    interactive: Optional[Interactive] = {}
    timestamp: Optional[int] = "1740649841"


class Status(BaseModel):
    status: str


class Profile(BaseModel):
    name: str


class ContactDetails(BaseModel):
    profile: Profile
    wa_id: str


class Value(BaseModel):
    metadata: Optional[dict[str, Any]] = [{}]
    messages: Optional[list[Message]] = [{}]
    statuses: Optional[list[Status]] = [{}]
    contacts: Optional[list[ContactDetails]] = []
    class Config:
        extra = "allow"


class Changes(BaseModel):
    value: Value


class Entry(BaseModel):
    changes: list[Changes]


class WhatsappIncomingRequest(BaseModel):
    entry: list[Entry]
