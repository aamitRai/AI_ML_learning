from pydantic import BaseModel


class Info(BaseModel):
    key: str
    value: str


class CreateTickets(BaseModel):
    tenantId: str
    apiKey: str
    message: str = []
    sender: str = "bot"
    senderId: str
    channel: int  = 0
    ebotifyCustomerId: str
    timestamp: float
    status: str
    info: list[Info]
