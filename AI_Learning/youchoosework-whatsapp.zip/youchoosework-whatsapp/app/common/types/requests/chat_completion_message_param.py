from pydantic import BaseModel
from typing import Literal


class Content(BaseModel):
    type: str = "text"
    text: str

class ChatCompletionMessageParam(BaseModel):
    role: str = Literal['system', 'user', 'assistant', 'developer']
    content: list[Content]
