from pydantic import BaseModel


class UpdateTickets(BaseModel):
    status: str
    ticketNo: str
