from pydantic import BaseModel, Field
from typing import Optional


class WorkerDetails(BaseModel):
    firstName: Optional[str] = None
    postCode: Optional[str] = None
    hourlyRate: Optional[str] = Field(validation_alias='wage', default=None)
    qualificationLevel: Optional[str] = None
    drivingLicense: Optional[str] = None


class Workers(BaseModel):
    workers: Optional[list[WorkerDetails]] = []
