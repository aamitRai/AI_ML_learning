from pydantic import BaseModel
from typing import Optional


class TicketDetails(BaseModel):
    isTicketFound: bool
    status: Optional[str] = ""
    ticketNo: Optional[str] = ""
