from pydantic import BaseModel


class UserDetails(BaseModel):
    location: str
    postCode: str
    longitude: float
    latitude: float
