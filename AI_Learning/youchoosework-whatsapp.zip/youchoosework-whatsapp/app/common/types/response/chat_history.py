from pydantic import BaseModel
from typing import Optional, Union


class MessageItem(BaseModel):
    _id: str
    type: str
    message: Union[str | dict]


class Conversation(BaseModel):
    sender: int
    message: list[MessageItem]


class ChatHistory(BaseModel):
    conversations: Optional[list[Conversation]] = []
