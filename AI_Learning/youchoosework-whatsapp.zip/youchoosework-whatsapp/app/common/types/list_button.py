from pydantic import BaseModel


class Row(BaseModel):
    id: str
    title: str


class Sections(BaseModel):
    rows: list[Row]


class Action(BaseModel):
    button: str
    sections: list[Sections]


class Body(BaseModel):
    text: str


class InteractiveBody(BaseModel):
    type: str = "list"
    body: Body
    action: Action


class Interactive(BaseModel):
    type: str = "interactive"
    interactive: InteractiveBody
  