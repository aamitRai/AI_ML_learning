import requests
from fastapi import Response


class RequestHelper:
        
    @staticmethod
    def get(url: str, params: dict  = None, headers: dict = None) -> Response:
        response = requests.get(url=url, params=params, headers=headers)
        response.raise_for_status()
        return response
    
    @staticmethod
    def put(url: str, payload: dict, headers: dict = None, params: dict = None) -> Response:
        response = requests.put(url=url, data=payload, headers=headers, params=params)
        response.raise_for_status()
        return response

    @staticmethod
    def post(url: str, payload: dict|str, headers: dict = None, params: dict = None) -> Response:
        response = requests.post(url=url, headers=headers, data=payload, params=params)
        response.raise_for_status()
        return response
