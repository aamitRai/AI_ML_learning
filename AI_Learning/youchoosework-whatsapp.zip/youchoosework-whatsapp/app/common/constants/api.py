CREATE_TICKET_URL = "{ticket_url}/api/ticket/create"
GET_TICKET_STATUS_URL = "{thanos_url}/api/v3/livechat/bot/{api_key}/ebotifyCustomerId/{sender_id}/status"
UPDATE_TICKET_STATUS_URL = "{thanos_url}/api/v3/livechat/bot/{api_key}/update"
GET_CHAT_HISTORY_URL = "{thanos_url}/api/v3/histories/bot/{api_key}/conversations/{sender_id}?page=1&limit=7"
ALLOWED_METHODS = ["GET", "POST", "OPTIONS", "PUT"]
SELECTED_ALL = ["*"]
CONTENT_TYPE = 'Content-Type'
APPLICATION_JSON = "application/json"
BEARER = "Bearer"
AUTHORIZATION = "Authorization"
ACCEPT = 'accept'
ORIGIN = "origin"
ORIGIN_URL = "https://app.ebotify.chat"
