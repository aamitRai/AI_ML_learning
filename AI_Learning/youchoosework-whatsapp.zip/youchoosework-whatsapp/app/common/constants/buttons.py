MENU_BUTTONS = [
    {
        "id": "available_today",
        "title": "Available today?"
    },
    {
        "id": "available_tomorrow",
        "title": "Available tomorrow?"
    },
    {
        "id": "recommended_available",
        "title": "Recommended & Available"
    },
    {
        "id": "qualified_available",
        "title": "Qualified & Available"
    },
    {
        "id": "live_agent",
        "title": "Live Agent"
    }
]

MENU_BUTTON_CAPTION = "Main Menu"


BUTTON_OPTIONS = [
    {
        "id": "5",
        "title": "available_today"
    },
    {
        "id": "4",
        "title": "available_tomorrow"
    },
    {
        "id": "3",
        "title": "recommended_available"
    },
    {
        "id": "2",
        "title": "qualified_available"
    },
    {
        "id": "1",
        "title": "Live Agent"
    }
]
