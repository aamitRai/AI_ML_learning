from fastapi import APIRouter, Body, Depends

from app.common.types.requests.whatsapp_incoming_request import WhatsappIncomingRequest
from app.controller.message_controller import MessageController
from app.utils.dependencies import Dependencies

router = APIRouter(prefix="/webhooks/whatsapp")


@router.post("/cloud-api")
async def get_response(request: WhatsappIncomingRequest = Body(), message_controller: MessageController = Depends(Dependencies().get_message_controller)) -> dict:
    response = await message_controller.message_controller(request=request)
    return response
