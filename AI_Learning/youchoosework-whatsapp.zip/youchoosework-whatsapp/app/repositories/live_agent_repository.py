from app.common.constants.logs import LIVE_AGENT_API_RESPONSE_LOG
from app.common.helpers.logger_helper import logger
from app.common.helpers.request_helper import RequestHelper


class LiveAgentRepository:

    async def send_message_to_live_agent(self, url: str, headers: dict, data: str) -> None:
        response = RequestHelper.post(url=url, headers=headers, payload=data)
        logger.info(f"{LIVE_AGENT_API_RESPONSE_LOG} {response.text}")
        return
