from openai import AsyncOpenAI
from openai.types.chat import ChatCompletion, ChatCompletionMessageParam

from app.common.constants.common import TYPE
from app.common.constants.open_ai import DEFAULT_MAX_TOKENS, DEFAULT_TEMPERATURE
from app.config.dot_env import Config


class OpenAIRepository:

    def __init__(self, client: AsyncOpenAI) -> None:
        self.__openai_client = client

    async def chat_completion(self, messages: list[ChatCompletionMessageParam], response_format: str = "text") -> ChatCompletion:
        response = self.__openai_client.chat.completions.create(
            model=Config.OPEN_AI_CHAT_MODEL,
            messages=messages,
            temperature=DEFAULT_TEMPERATURE,
            max_tokens=DEFAULT_MAX_TOKENS,
            response_format={TYPE: response_format}
        )
        return response
