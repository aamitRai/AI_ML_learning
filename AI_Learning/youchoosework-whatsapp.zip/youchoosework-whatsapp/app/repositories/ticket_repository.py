from app.common.constants.api import AUTHORIZATION, BEARER, CREATE_TICKET_URL, GET_TICKET_STATUS_URL, ORIGIN, ORIGIN_URL, UPDATE_TICKET_STATUS_URL, CONTENT_TYPE, APPLICATION_JSON
from app.common.constants.common import BODY
from app.common.constants.logs import CHAT_HISTORY_LOG, CREATE_TICKET_RESPONSE_LOG, CREATE_TICKET_PAYLOAD_LOG, GET_TICKET_RESPONSE_LOG, UPDATE_TICKET_PAYLOAD_LOG, UPDATE_TICKET_RESPONSE_LOG
from app.common.helpers.logger_helper import logger
from app.common.helpers.request_helper import RequestHelper
from app.common.types.requests.update_ticket import UpdateTickets
from app.config.dot_env import  Config

CONVERSATION = "conversations"


class TicketRepository:

    async def create_ticket(self, ticket_details: str) -> None:
        logger.info(f"{CREATE_TICKET_PAYLOAD_LOG} {ticket_details}")
        response = RequestHelper.post(
            url=CREATE_TICKET_URL.format(ticket_url=Config.TICKET_URL),
            headers={CONTENT_TYPE: APPLICATION_JSON},
            payload=ticket_details
        )
        logger.info(f"{CREATE_TICKET_RESPONSE_LOG} {response.text}")
        return

    async def get_ticket(self, sender_id: str) -> dict:
        url = GET_TICKET_STATUS_URL.format(
            thanos_url=Config.THANOS_URL,
            api_key=Config.EBOTIFY_API_KEY,
            sender_id=sender_id
        )
        headers = {
            ORIGIN: ORIGIN_URL,
            CONTENT_TYPE: APPLICATION_JSON,
            AUTHORIZATION: f"{BEARER} {Config.THANOS_TOKEN}"
        }
        response = RequestHelper.get(url=url, headers=headers)
        logger.info(f"{GET_TICKET_RESPONSE_LOG} {response.text}")
        return response.json()

    async def update_ticket_status(self, ticket_details: UpdateTickets) -> None:
        url = UPDATE_TICKET_STATUS_URL.format(thanos_url=Config.THANOS_URL, api_key=Config.EBOTIFY_API_KEY)
        headers = {
            CONTENT_TYPE: APPLICATION_JSON,
            AUTHORIZATION: f"{BEARER} {Config.THANOS_TOKEN}"
        }
        ticket_details_dict = ticket_details.model_dump_json()
        logger.info(f"{UPDATE_TICKET_PAYLOAD_LOG} {ticket_details_dict}")
        response = RequestHelper.put(url=url, headers=headers, payload=ticket_details_dict)
        logger.info(f"{UPDATE_TICKET_RESPONSE_LOG} {response.text}")
        return

    async def get_chat_history(self, url: str) -> dict:
        headers = {
            CONTENT_TYPE: APPLICATION_JSON,
            AUTHORIZATION: f"{BEARER} {Config.THANOS_TOKEN}"
        }
        response = RequestHelper.get(url=url, headers=headers)
        logger.info(f"{CHAT_HISTORY_LOG}{response.status_code} & {len(response.json().get(BODY, {}).get(CONVERSATION))}")
        return response.json()

