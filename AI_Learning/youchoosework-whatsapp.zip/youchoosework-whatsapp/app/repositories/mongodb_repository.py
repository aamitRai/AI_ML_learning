from typing import Any
from pymongo import MongoClient

from app.common.enums.mongo_tables_enum import MongoTableEnum
from app.config.dot_env import Config


class MongoDbRepository:

    def __init__(self, client: MongoClient) -> None:
        self.client = client
        self.db = self.client[Config.MONGO_DB_NAME]
    
    async def get_query_count(self, query: dict, table: MongoTableEnum) -> int:
        table_name = self.db[table]
        return table_name.count_documents(query)

    async def get_query_response(self, query: dict, table: MongoTableEnum) -> Any:
        table_name = self.db[table]
        return table_name.find(query)

    async def get_qualification_level(self, table: MongoTableEnum) -> Any:
        table_name = self.db[table]
        return table_name.find({})

    async def get_wages_details(self, table: MongoTableEnum) -> Any:
        table_name = self.db[table]
        return table_name.find({})
