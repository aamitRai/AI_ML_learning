from typing import Optional

from app.common.constants.common import NAME, MOBILE_NO
from app.common.enums.message_type_enum import MessageTypesEnum
from app.common.types.requests.bot_message import Info
from app.common.types.requests.whatsapp_incoming_request import ContactDetails, Interactive, Message, Value
from app.services.live_agent_service import LiveAgentService
from app.services.bot_message_service import BotMessageService


class MessageProcessor:

    def __init__(self, live_agent_service: LiveAgentService, bot_message_service: BotMessageService) -> None:
        self.__live_agent_service = live_agent_service
        self.__bot_message_service = bot_message_service

    async def process_message(self, incoming_request: Value) -> dict:
        sender_id = incoming_request.messages[0].sender
        contact_details = incoming_request.contacts[0]
        text_message = self.__extract_message(message=incoming_request.messages[0])
        user_info = self.__extract_user_info(contact_details=contact_details)
        response = await self.__bot_message_service.get_text_response(text=text_message, sender_id=sender_id)
        await self.__live_agent_service.send_bot_message_to_live_agent(sender_id=sender_id, user_info=user_info, messages=response)
        return {"status": "ohk"}
    
    def __extract_user_info(self, contact_details: ContactDetails) -> list[Info]:
        return [
            Info(key=NAME, value=contact_details.profile.name), 
            Info(key=MOBILE_NO, value=contact_details.wa_id)
        ]

    def __extract_message(self, message: Message) -> str | None:
        msg_type = message.type
        if not msg_type:
            return
        msg = self.__extract_message_via_type(message, msg_type)
        if msg:
            return msg
        return "menu"

    def __extract_message_via_type(self, message: Message, message_type: str) -> str | None:
        match message_type:
            case MessageTypesEnum.TEXT.value:
                return self.__extract_text(message)
            case MessageTypesEnum.BUTTON.value:
                return self.__extract_button(message)
            case MessageTypesEnum.INTERACTIVE.value:
                return self.__extract_interactive(message)
        return

    def __extract_text(self, message: Message) -> str:
        return message.text.body

    def __extract_interactive(self, message: Message) -> Optional[str]:
        interactive_message = message.interactive
        interactive_type = interactive_message.type
        if interactive_type == MessageTypesEnum.LIST_REPLY.value:
            return self.__extract_list_reply(interactive_message=interactive_message)
        if interactive_type == MessageTypesEnum.BUTTON_REPLY.value:
            return self.__extract_button_reply(interactive_message=interactive_message)

    def __extract_button_reply(self, interactive_message: Interactive) -> str:
        return interactive_message.button_reply.id

    def __extract_list_reply(self, interactive_message: Interactive) -> str:
        return interactive_message.list_reply.id

    def __extract_button(self, message: Message) -> str:
        return message.button.text
