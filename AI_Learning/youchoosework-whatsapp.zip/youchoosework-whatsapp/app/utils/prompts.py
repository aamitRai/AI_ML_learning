from datetime import datetime

from app.common.constants.common import DAY_FORMAT, TYPE, TEXT
from app.common.constants.prompts import QUALIFIED_AND_RECOMMENDED_QUERY_PROMPT, QUERY_PROMPT, LIST_WORKER_DETAILS_PROMPT, ALTERNATE_QUERY_PROMPT
from app.common.enums.prompt_role_enum import PromptRoleEnum
from app.common.types.requests.chat_completion_message_param import ChatCompletionMessageParam
from app.common.types.response.user_details import UserDetails


class Prompts:

    @staticmethod
    def query_prompt(message: str,  qualification: list[dict] = "", user_details: UserDetails = "") -> list[ChatCompletionMessageParam]:
            today = datetime.now()
            date = today.strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "+00:00"
            day = today.strftime(DAY_FORMAT)
            return [ChatCompletionMessageParam(
                        role=PromptRoleEnum.DEVELOPER.value,
                        content=[
                            {
                                TYPE: TEXT,
                                TEXT: QUERY_PROMPT.format(
                                     date=date, 
                                     day=day, 
                                     user_details=user_details.model_dump() if user_details else "",
                                     qualification=qualification)
                            }
                        ]
                    ),
                    ChatCompletionMessageParam(
                        role=PromptRoleEnum.SYSTEM.value,
                        content=[
                            {
                                TYPE: TEXT,
                                TEXT: f"User Query : {message}"
                            }
                        ]
                    )
                ]

    @staticmethod
    def worker_details_prompt(user_details: UserDetails, worker_details: list[dict], qualification: list[dict], hourly_rate_data: list[dict]) -> list[ChatCompletionMessageParam]:
        prompt = LIST_WORKER_DETAILS_PROMPT
        return [ChatCompletionMessageParam(
                    role=PromptRoleEnum.SYSTEM.value,
                    content=[
                        {
                            TYPE: TEXT,
                            TEXT: prompt.format(user_details=user_details.model_dump(), qualification=qualification, workers=worker_details, hourly_rates=hourly_rate_data)
                        }
                    ]
                )
            ]

    @staticmethod
    def alternate_query_prompt(query: dict, user_question: str, user_details: UserDetails) -> list[ChatCompletionMessageParam]:
        return [
            ChatCompletionMessageParam(
                    role=PromptRoleEnum.DEVELOPER.value,
                    content=[
                        {
                            TYPE: TEXT,
                            TEXT: ALTERNATE_QUERY_PROMPT.format(user_details=user_details.model_dump(), mongo_query=query, user_question=user_question)
                        }
                    ]
                )
        ]
    
    @staticmethod
    def qualified_and_recommended_query_prompt(user_details: UserDetails, worker_details: list[dict], qualification: list[dict], hourly_rate_data:  list[dict]) -> list[ChatCompletionMessageParam]:
        return [ChatCompletionMessageParam(
                    role=PromptRoleEnum.SYSTEM.value,
                    content=[
                        {
                            TYPE: TEXT,
                            TEXT: QUALIFIED_AND_RECOMMENDED_QUERY_PROMPT.format(user_details=user_details.model_dump(), qualification=qualification, workers=worker_details, hourly_rates=hourly_rate_data)
                        }
                    ]
                )
            ]
