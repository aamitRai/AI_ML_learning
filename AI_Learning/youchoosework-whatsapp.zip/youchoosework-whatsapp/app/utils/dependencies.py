from openai import OpenAI
from pymongo import MongoClient

from app.common.constants.open_ai import DEFAULT_TIMEOUT
from app.config.dot_env import Config
from app.controller.message_controller import MessageController
from app.processor.message_processor import MessageProcessor
from app.repositories.live_agent_repository import LiveAgentRepository
from app.repositories.mongodb_repository import MongoDbRepository
from app.repositories.open_ai_repository import OpenAIRepository
from app.repositories.ticket_repository import TicketRepository
from app.services.bot_message_service import BotMessageService
from app.services.live_agent_service import LiveAgentService
from app.services.mongodb_service import MongoDbService
from app.services.open_ai_service import OpenAIService
from app.services.ticket_service import TicketService

print("api_key=Config.OPEN_AI_API_KEY",Config.OPEN_AI_API_KEY)
class Dependencies:

    def get_message_controller(self) -> MessageController:
        self.ticket_repository = TicketRepository()
        self.open_ai_repository = OpenAIRepository(client=OpenAI(api_key=Config.OPEN_AI_API_KEY, timeout=DEFAULT_TIMEOUT))
        self.open_ai_service = OpenAIService(open_ai_repository=self.open_ai_repository)
        self.ticket_service = TicketService(ticket_repository=self.ticket_repository)
        self.client = MongoClient(Config.MONGO_CONNECTION_STRING)
        self.mongo_db_repository = MongoDbRepository(client=self.client)
        self.mongo_db_service = MongoDbService(mongo_db_repository=self.mongo_db_repository)
        self.live_agent_repository = LiveAgentRepository()
        self.live_agent_service = LiveAgentService(
            ticket_service=self.ticket_service,
            live_agent_repository=self.live_agent_repository
        )
        self.response_service = BotMessageService(
            ticket_service=self.ticket_service, 
            mongo_db_service=self.mongo_db_service,
            open_ai_service=self.open_ai_service
        )
        self.message_processor = MessageProcessor(live_agent_service=self.live_agent_service, bot_message_service=self.response_service)
        self.message_controller = MessageController(
            message_processor=self.message_processor, 
            ticket_service=self.ticket_service, 
            live_agent_service=self.live_agent_service
        )
        return self.message_controller
