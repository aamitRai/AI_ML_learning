import json

from app.common.types.requests.chat_completion_message_param import ChatCompletionMessageParam
from app.common.helpers.logger_helper import logger
from app.repositories.open_ai_repository import OpenAIRepository

JSON_OBJECT = "json_object"


class OpenAIService:

    def __init__(self, open_ai_repository: OpenAIRepository) -> None:
        self.__openai_repository = open_ai_repository

    async def chat_completion(self, messages: list[ChatCompletionMessageParam] = None, response_format: str = "text") -> str:
        messages = [message.model_dump() for message in messages]
        completions = await self.__openai_repository.chat_completion(messages=messages, response_format=response_format)
        return completions.choices[0].message.content

    async def get_worker_query(self, messages: list[ChatCompletionMessageParam] = None) -> dict:
        query = await self.chat_completion(messages=messages, response_format=JSON_OBJECT)
        logger.info(query)
        return json.loads(query)
