from datetime import datetime

from app.common.constants.api import GET_CHAT_HISTORY_URL
from app.common.constants.common import BODY, MOBILE_NO
from app.common.enums.status_enum import StatusEnum
from app.common.types.requests.create_ticket import CreateTickets, Info
from app.common.types.requests.update_ticket import UpdateTickets
from app.common.types.response.chat_history import ChatHistory
from app.common.types.response.ticket_details import TicketDetails
from app.config.dot_env import Config
from app.repositories.ticket_repository import TicketRepository

INTENT = "intent"
OUTGOING = "outgoing"


class TicketService:

    def __init__(self, ticket_repository: TicketRepository) -> None:
        self.__tickets_repository = ticket_repository

    async def get_ticket_status(self, sender_id: str) -> str:
        response = await self.__tickets_repository.get_ticket(sender_id=sender_id)
        ticket_details = TicketDetails(**response.get(BODY))
        if ticket_details.isTicketFound:
            return ticket_details.status
        else:
            await self.create_ticket(sender_id=sender_id)
            return StatusEnum.HIDDEN.value

    async def is_user_exist(self, sender_id: str) -> bool:
        response = await self.__tickets_repository.get_ticket(sender_id=sender_id)
        ticket_details = TicketDetails(**response.get(BODY))
        if ticket_details.isTicketFound:
            if ticket_details.status != StatusEnum.CLOSED.value:
                return True
        return False
    
    async def create_ticket_if_user_not_exist(self, sender_id: str) -> None:
        is_user_exist = await self.is_user_exist(sender_id=sender_id)
        if not is_user_exist:
            await self.create_ticket(sender_id=sender_id)
        return

    async def create_ticket(self, sender_id: str) -> None:
        ticket_details = CreateTickets(
            tenantId=Config.EBOTIFY_TENANT_ID,
            apiKey=Config.EBOTIFY_API_KEY,
            senderId=sender_id,
            ebotifyCustomerId=sender_id,
            timestamp=int(datetime.now().timestamp() * 1_000_000_000),
            status=StatusEnum.HIDDEN.value,
            info=[
                Info( key=INTENT, value=OUTGOING),
                Info(key=MOBILE_NO, value=sender_id)
            ]
        ).model_dump_json()
        await self.__tickets_repository.create_ticket(ticket_details=ticket_details)
        return

    async def update_ticket_status(self, sender_id: str, status: str) -> None:
        response = await self.__tickets_repository.get_ticket(sender_id=sender_id)
        ticket_details = TicketDetails(**response.get(BODY))
        if ticket_details.isTicketFound:
            updated_ticket_details = UpdateTickets(status=status, ticketNo=ticket_details.ticketNo)
            await self.__tickets_repository.update_ticket_status(ticket_details=updated_ticket_details)
        return

    async def get_chat_history(self, sender_id: str) -> ChatHistory:
        url = GET_CHAT_HISTORY_URL.format(
            thanos_url=Config.THANOS_URL, 
            api_key=Config.EBOTIFY_API_KEY,
            sender_id=sender_id
        )
        response = await self.__tickets_repository.get_chat_history(url=url)
        chat_history = ChatHistory(**response.get(BODY))
        return chat_history
