import json
import re
from datetime import datetime, timedelta
from typing import Any

from app.common.constants.buttons import BUTTON_OPTIONS, MENU_BUTTON_CAPTION, MENU_BUTTONS
from app.common.constants.common import BODY, DATE_TIME_REGEX, DATE_TIME_FORMAT, GREET_TEXT, ID, INTERACTIVE, LIST, LIST_REPLY, LIVE_AGENT_TEXT, MENU_TEXT, TEXT, TITLE, TYPE, WORKER_FILTER_TEXT, WORKERS
from app.common.constants.messages import GREET_MSG, LIVE_AGENT_CONNECTING_MSG, LIVE_AGENT_UNAVAILABLE_MSG, MAIN_MENU_MSG, UNAUTHENTICATED_NUMBER_MSG
from app.common.enums.message_type_enum import MessageTypesEnum
from app.common.enums.prompt_role_enum import PromptRoleEnum
from app.common.enums.status_enum import StatusEnum
from app.common.helpers.logger_helper import logger
from app.common.types.list_button import *
from app.common.types.requests.chat_completion_message_param import ChatCompletionMessageParam, Content
from app.common.types.response.user_details import UserDetails
from app.config.dot_env import Config
from app.services.mongodb_service import MongoDbService
from app.services.open_ai_service import OpenAIService
from app.services.ticket_service import TicketService
from app.utils.prompts import Prompts


class BotMessageService:

    def __init__(self, ticket_service: TicketService, mongo_db_service: MongoDbService, open_ai_service: OpenAIService) -> None:
        self.__ticket_service = ticket_service
        self.__mongo_db_service = mongo_db_service
        self.__open_ai_service = open_ai_service

    async def get_text_response(self, text: str, sender_id: str) -> list[dict[str, Any]]:
        try:
            if await self.__mongo_db_service.is_user_verified(sender_id=sender_id):
                if text.startswith("TIC"):
                    button = {btn.get(ID): btn.get(TITLE) for btn in BUTTON_OPTIONS}
                    text = button.get(text[-1]) 
                if text.lower() in GREET_TEXT:
                    message = self.get_list_menu_msg(text=GREET_MSG, buttons=MENU_BUTTONS)
                elif text.lower() in MENU_TEXT:
                    message = self.get_list_menu_msg(text=MAIN_MENU_MSG, buttons=MENU_BUTTONS)
                elif text.lower() in LIVE_AGENT_TEXT:
                    if bool(Config.IS_LIVE_AGENT):
                        await self.__ticket_service.update_ticket_status(sender_id=sender_id, status=StatusEnum.NEW.value)
                        message = [{TYPE: MessageTypesEnum.TEXT.value, TEXT: LIVE_AGENT_CONNECTING_MSG}]
                    else:
                        message = self.get_list_menu_msg(text=LIVE_AGENT_UNAVAILABLE_MSG, buttons=MENU_BUTTONS)
                elif text.lower() in WORKER_FILTER_TEXT:
                    user_details = await self.__mongo_db_service.get_user_details(sender_id=sender_id)
                    worker_filter_query = await self.filter_query(worker_filter=text)
                    if text == "qualified_available":
                        text = "I need qualified worker available on today and tomorrow."
                    if text == "recommended_available":
                        text = "I need recommended worker available on today and tomorrow." 
                    completion_response = await self.worker_by_query(query=worker_filter_query, text=text, sender_id=sender_id, user_details=user_details)
                    message = [{TYPE: MessageTypesEnum.TEXT.value, TEXT: completion_response}]
                else:
                    user_details = await self.__mongo_db_service.get_user_details(sender_id=sender_id)
                    qualification_levels = await self.__mongo_db_service.get_qualification_levels()
                    query_prompt = Prompts.query_prompt(message=text, user_details=user_details, qualification=qualification_levels)
                    query_response = await self.__open_ai_service.get_worker_query(messages=query_prompt)
                    completion_response = await self.worker_by_query(query=query_response, text=text, sender_id=sender_id, user_details=user_details)
                    if completion_response.lower() in MENU_TEXT:
                        message = self.get_list_menu_msg(text=MAIN_MENU_MSG, buttons=MENU_BUTTONS)
                    elif completion_response.lower() in LIVE_AGENT_TEXT:
                        if bool(Config.IS_LIVE_AGENT):
                            await self.__ticket_service.update_ticket_status(sender_id=sender_id, status=StatusEnum.NEW.value)
                            message = [{TYPE: MessageTypesEnum.TEXT.value, TEXT: LIVE_AGENT_CONNECTING_MSG}]
                        else:
                            message = self.get_list_menu_msg(text=LIVE_AGENT_UNAVAILABLE_MSG, buttons=MENU_BUTTONS)
                    else:
                        message = [{TYPE: MessageTypesEnum.TEXT.value, TEXT: completion_response}]
            else:
                message = [{TYPE: MessageTypesEnum.TEXT.value, TEXT: UNAUTHENTICATED_NUMBER_MSG}]
        except Exception as ex:
            logger.exception(ex)
            message = self.get_list_menu_msg(text="Something went wrong can you please try again.", buttons=MENU_BUTTONS)
        return message

    def update_date_type(self, query: dict) -> dict:
        if isinstance(query, dict):
            for key, value in query.items():
                if key == 'date' or key == "availability.date" or key == "$date":
                    if isinstance(value, dict):
                        for key, _value in value.items():
                            if isinstance(value, (dict, list)):
                                self.update_date_type(value)
                            if isinstance(_value, str):
                                if re.match(DATE_TIME_REGEX, _value):
                                    value[key] = datetime.strptime(_value, DATE_TIME_FORMAT)
                    elif isinstance(value, str) and re.match(DATE_TIME_REGEX, value):
                        query[key] = datetime.strptime(value, DATE_TIME_FORMAT)
                elif isinstance(value, (dict, list)):
                    self.update_date_type(value)
        elif isinstance(query, list):
            for index, item in enumerate(query):
                if isinstance(item, str):
                    if re.match(DATE_TIME_REGEX, item):
                        query[index] = datetime.strptime(item, DATE_TIME_FORMAT)
                self.update_date_type(item)
        return query

    async def filter_query(self, worker_filter: str) -> dict:
        match worker_filter:
            case "available_today" | "available_tomorrow":
                query_prompt = Prompts.query_prompt(message=worker_filter)
                return await self.__open_ai_service.get_worker_query(messages=query_prompt)
            case "recommended_available":
                return await self.recommended_worker_query()
            case "qualified_available":
                return await self.qualified_worker_query()
            
    async def recommended_worker_query(self) -> dict:
        today , tomorrow = self.get_today_tomorrow_date()
        return  {"$and": [
                    {"overallRating": "recommended"},
                    { "openToWork": True },
                    { "isVerified": True },
                    { "isEnabled": True },
                    {
                    "availability": {
                        "$elemMatch": {
                        "date": {
                            "$in": [today, tomorrow]
                        },
                        "$or": [
                            { "jobOfferAccepted": False },
                            {
                            "jobOfferAccepted": {"$exists": False }
                            }
                        ]
                        }
                    }
                    }
                ]
            }

    async def qualified_worker_query(self) -> dict:
        today , tomorrow = self.get_today_tomorrow_date()
        qualification_levels = await self.__mongo_db_service.get_qualification_levels()
        qualification_levels = {qualification_id : level for qualification_id, level in qualification_levels.items() if level.lower() != "unqualified"}
        return  {"openToWork": True, "isVerified": True, "isEnabled": True,"qualificationLevel": {"$in": list(qualification_levels.keys())}, "availability": {
                "$elemMatch": {
                    "date":{"$in": [today, tomorrow]},
                    "$or": [
                        {
                            "jobOfferAccepted": False
                        },
                        {
                            "jobOfferAccepted": {
                                "$exists": False
                            }
                        }
                    ]
                }
            }
        }

    async def worker_by_query(self, query: dict, text: str, sender_id: str, user_details: UserDetails) -> str:
        chat_history = await self.get_chat_history(sender_id=sender_id, text=text)
        updated_query = self.update_date_type(query=query) # Update date type str to datetime
        workers_details = await self.__mongo_db_service.get_workers_details(query=updated_query)
        if not workers_details.get(WORKERS):
            alternate_query_prompt = Prompts.alternate_query_prompt(query=query, user_question=text, user_details=user_details)
            alternate_query = await self.__open_ai_service.get_worker_query(messages=alternate_query_prompt)
            updated_query = self.update_date_type(query=alternate_query) # Update date type str to datetime
            workers_details = await self.__mongo_db_service.get_workers_details(query=updated_query)
        qualification_levels = await self.__mongo_db_service.get_qualification_levels()
        hourly_rate_data = await self.__mongo_db_service.get_wages_details()
        workers_details_prompt = Prompts.worker_details_prompt(
            user_details=user_details,
            worker_details=workers_details,
            qualification=qualification_levels,
            hourly_rate_data=hourly_rate_data
        )
        if text in ["I need recommended worker available on today and tomorrow.", "I need qualified worker available on today and tomorrow."]:
            logger.info("-----Inside qualified and recommended prompt -----")
            workers_details_prompt = Prompts.qualified_and_recommended_query_prompt(
                user_details=user_details,
                worker_details=workers_details,
                qualification=qualification_levels,
                hourly_rate_data=hourly_rate_data
            )
        message = await self.__open_ai_service.chat_completion(messages=workers_details_prompt+chat_history)
        return message

    async def get_chat_history(self, sender_id: str, text: str) -> list[ChatCompletionMessageParam]:
        chat_history = []
        history = await self.__ticket_service.get_chat_history(sender_id=sender_id)
        for conversation in history.conversations:
            if conversation.sender == 2:
                message = conversation.message[0].message
                if isinstance(message, str):
                    try:
                        message = json.loads(message).get(LIST_REPLY).get(TITLE)
                    except json.JSONDecodeError:
                        message = message      
                chat_history.append(ChatCompletionMessageParam(
                    role=PromptRoleEnum.USER,
                    content=[Content(text=conversation.message[0].message)]
                ))
            else:
                msg_type = conversation.message[0].type
                message = conversation.message[0].message
                if msg_type == MessageTypesEnum.INTERACTIVE.value:
                    if type(message) == str:
                        if json.loads(message).get(TYPE) == LIST:
                            message = json.loads(message).get(BODY, {}).get(TEXT)
                    else:
                        message = message.get(INTERACTIVE, {}).get(BODY, {}).get(TEXT)
                if message not in[MAIN_MENU_MSG, LIVE_AGENT_CONNECTING_MSG, LIVE_AGENT_UNAVAILABLE_MSG, LIVE_AGENT_TEXT]:
                    if not (message.startswith("No flexible childcare practitioners") or  message.startswith("Sorry, I can only assist")):
                        chat_history.append(ChatCompletionMessageParam(
                            role=PromptRoleEnum.ASSISTANT,
                            content=[Content(text=message)]
                        ))
                else:
                    if chat_history:
                        chat_history.pop(-1)
        chat_history.append(ChatCompletionMessageParam(
                    role=PromptRoleEnum.USER,
                    content=[Content(text=text)]
                ))
        return chat_history

    def get_list_menu_msg(self, text: str, buttons: list[dict]) -> list[dict]:
        return [
                    {
                        TYPE: MessageTypesEnum.INTERACTIVE.value, 
                        INTERACTIVE: Interactive(
                        interactive=InteractiveBody(
                            body=Body(text=text), 
                            action=Action(
                                button=MENU_BUTTON_CAPTION, 
                                sections=[Sections(rows=buttons)]
                            )
                        )
                    ).model_dump()
                }
            ]

    def get_today_tomorrow_date(self):
        today_date = datetime.now()
        # If today is Friday (weekday == 4), skip to Monday (+3 days)
        if today_date.weekday() == 4:
            tomorrow_date = today_date + timedelta(days=3)
        # If today is Saturday, skip to Monday (+2 days)
        elif today_date.weekday() == 5:
            tomorrow_date = today_date + timedelta(days=2)
        else:
            tomorrow_date = today_date + timedelta(days=1)
        today = today_date.strftime("%Y-%m-%dT00:00:00.00+00:00")
        tomorrow = tomorrow_date.strftime("%Y-%m-%dT00:00:00.00+00:00")
        return today, tomorrow
