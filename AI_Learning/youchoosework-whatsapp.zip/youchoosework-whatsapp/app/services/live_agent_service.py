import time

from app.common.constants.api import ACCEPT, APPLICATION_JSON, CONTENT_TYPE
from app.common.constants.common import MESSAGE, TIMESTAMP, TYPE
from app.common.constants.logs import BOT_MSG_PAYLOAD_LOG, USER_MSG_PAYLOAD_LOG
from app.common.helpers.logger_helper import logger
from app.common.types.requests.bot_message import BotMessageData, Info
from app.common.types.requests.whatsapp_incoming_request import Value
from app.config.dot_env import Config
from app.repositories.live_agent_repository import LiveAgentRepository
from app.services.ticket_service import TicketService


class LiveAgentService:

    def __init__(self, ticket_service: TicketService, live_agent_repository: LiveAgentRepository) -> None:
        self.__ticket_service = ticket_service
        self.__live_agent_repository = live_agent_repository

    async def send_user_message_to_live_agent(self, incoming_value: Value, sender_id: str) -> None:
        await self.__ticket_service.create_ticket_if_user_not_exist(sender_id=sender_id)
        incoming_value.ignoreTicketInfo = True
        payload = incoming_value.model_dump_json()
        headers = {ACCEPT: APPLICATION_JSON, CONTENT_TYPE: APPLICATION_JSON}
        url = f"{Config.LIVE_AGENT_URL}/{Config.LIVE_AGENT_URL_USER_MESSAGE}?oId={Config.EBOTIFY_ORGANIZATION_ID}&tId={Config.EBOTIFY_TENANT_ID}&bId={Config.EBOTIFY_API_KEY}&isFeedbackEnabled={Config.HAS_FEEDBACK_ENABLED}&skipCustomerDetailsUpdate={Config.SKIP_CUSTOMER_DETAILS_UPDATE}&useEbotifyCustomerName={Config.USE_EBOTIFY_CUSTOMER_NAME}"
        logger.info(f"{USER_MSG_PAYLOAD_LOG} {payload}")
        await self.__live_agent_repository.send_message_to_live_agent(
            url=url,
            headers=headers,
            data=payload
        )
        return

    async def send_bot_message_to_live_agent(self, sender_id: str, user_info: list[Info], messages: list[dict]) -> None:
        for message in messages:
            messages = [{
                TYPE: message.get(TYPE),
                MESSAGE: message.get(message.get(TYPE)),
                TIMESTAMP: time.time() * 1000000000
            }]
            bot_message_payload = BotMessageData(
                organisationId=Config.EBOTIFY_ORGANIZATION_ID,
                tenantId=Config.EBOTIFY_TENANT_ID,
                botId=Config.EBOTIFY_API_KEY,
                customerId=sender_id,
                userInfo=user_info,
                messages=messages,
                channelType=0
            ).model_dump_json()
            logger.info(f"{BOT_MSG_PAYLOAD_LOG} {bot_message_payload}")
            url = f'{Config.LIVE_AGENT_URL}/{Config.LIVE_AGENT_URL_BOT_MESSAGE}?oId={Config.EBOTIFY_ORGANIZATION_ID}&tId={Config.EBOTIFY_TENANT_ID}&bId={Config.EBOTIFY_API_KEY}'
            await self.__live_agent_repository.send_message_to_live_agent(
                url=url,
                headers={CONTENT_TYPE: APPLICATION_JSON},
                data=bot_message_payload
            )
        return
