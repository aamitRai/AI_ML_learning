import random
import re
from typing import Any

from app.common.constants.common import _ID, ALTERNATE_PHONE, NAME, PHONE_NUMBER, POSTCODE, WAGE
from app.common.constants.logs import WORKER_COUNT_LOG
from app.common.enums.mongo_tables_enum import MongoTableEnum
from app.common.helpers.logger_helper import logger
from app.common.types.response.user_details import UserDetails
from app.common.types.response.workers_details import WorkerDetails, Workers
from app.repositories.mongodb_repository import MongoDbRepository


class MongoDbService:

    def __init__(self, mongo_db_repository: MongoDbRepository) -> None:
        self.__mongo_db_repository = mongo_db_repository

    async def is_user_verified(self, sender_id: str) -> bool:
        number_regex = self.get_number_regex(sender_id=sender_id)
        number_regex_without_country_code = self.get_number_regex(sender_id=sender_id[-10:])
        number_regex_with_zero = self.get_number_regex(sender_id=f"0{sender_id[-10:]}")
        query = {"$or": [
            { PHONE_NUMBER: { "$regex": number_regex }},
            { ALTERNATE_PHONE: { "$regex": number_regex }},
            { PHONE_NUMBER: { "$regex": number_regex_without_country_code }},
            { ALTERNATE_PHONE: { "$regex": number_regex_without_country_code}},
            { PHONE_NUMBER: { "$regex": number_regex_with_zero }},
            { ALTERNATE_PHONE: { "$regex": number_regex_with_zero }}
        ]}
        if await self.__mongo_db_repository.get_query_count(query=query, table=MongoTableEnum.CENTERS):
            return True
        return False

    async def get_workers_details(self, query: dict) -> list[dict]:
        workers = await self.__mongo_db_repository.get_query_response(query=query, table=MongoTableEnum.WORKERS)
        workers_list = workers.to_list() # convert the query object into list
        logger.info(f"{WORKER_COUNT_LOG} {len(workers_list)}")
        if len(workers_list) > 4:
            workers_list = random.sample(workers_list, 4)
        workers_details = Workers(workers=[WorkerDetails(**{**worker, POSTCODE: worker.get(POSTCODE).replace(' ', '')[:-3] + '###'}) for worker in workers_list])
        return workers_details.model_dump()

    async def get_qualification_levels(self) -> dict:
        qualification_levels = await self.__mongo_db_repository.get_qualification_level(table=MongoTableEnum.QUALIFICATIONS)
        qualification_levels = qualification_levels.to_list()
        levels = {}
        for level in qualification_levels:
            levels.update({str(level.get(_ID)): level.get(NAME)})
        return levels
    
    async def get_wages_details(self) -> dict:
        wages_details = await self.__mongo_db_repository.get_wages_details(table=MongoTableEnum.WAGES)
        wages_details = wages_details.to_list()
        all_wages = {}
        for wage in wages_details:
            all_wages.update({str(wage.get(_ID)): wage.get(WAGE)})
        return all_wages

    async def get_user_details(self, sender_id: str) -> UserDetails:
        number_regex = self.get_number_regex(sender_id=sender_id)
        number_regex_without_country_code = self.get_number_regex(sender_id=sender_id[-10:])
        number_regex_with_zero = self.get_number_regex(sender_id=f"0{sender_id[-10:]}")
        query = {"$or": [
            { PHONE_NUMBER: { "$regex": number_regex }},
            { ALTERNATE_PHONE: { "$regex": number_regex }},
            { PHONE_NUMBER: { "$regex": number_regex_without_country_code }},
            { ALTERNATE_PHONE: { "$regex": number_regex_without_country_code}},
            { PHONE_NUMBER: { "$regex": number_regex_with_zero }},
            { ALTERNATE_PHONE: { "$regex": number_regex_with_zero }}
        ]}
        user_details = await self.__mongo_db_repository.get_query_response(query=query, table=MongoTableEnum.CENTERS)
        return UserDetails(**user_details[0])

    def get_number_regex(self, sender_id: str) -> Any:
        pattern = ".*".join(sender_id)
        return re.compile(pattern)
